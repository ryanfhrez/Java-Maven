
public class Shouter {

	public void shout(String message) {
		
		String shoutMessage = message.toUpperCase() + '!';
		
		System.out.println(shoutMessage);
		
	}
	
}
