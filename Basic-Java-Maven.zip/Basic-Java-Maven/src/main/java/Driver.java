
public class Driver {

	public static void main(String[] args) {
		Shouter shouter = new Shouter();
		
		shouter.shout("hurrah");
	}

}
